import os

def parse_xyz_file(filename):
    clusters = []
    with open(filename, 'r') as f:
        lines = f.readlines()
        i = 0
        while i < len(lines):
            if lines[i].strip().isdigit():
                num_atoms = int(lines[i].strip())
                cluster = lines[i+1:i+2+num_atoms]  
                clusters.append(cluster)
                i += 2 + num_atoms
            else:
                i += 1
    return clusters

def filter_ion_clusters(clusters, ion):
    ion_clusters = []
    for cluster in clusters:
        if any(ion in line for line in cluster):
            ion_clusters.append(cluster)
    return ion_clusters

def parse_cluster(cluster):
    atoms = []
    for line in cluster:
        parts = line.split()
        if len(parts) >= 4: 
            atom = parts[0]
            coords = list(map(float, parts[1:4]))
            atoms.append((atom, coords))
    return atoms

def generate_dimers(atoms, ion):
    water_molecules = []  # Group oxygen with its associated hydrogens as a single water molecule
    ion_atom = None

    i = 0
    while i < len(atoms):
        atom, coords = atoms[i]
        if atom == 'O':
            # Assume each O is followed by its 2 H atoms for water
            water_molecules.append([atoms[i], atoms[i+1], atoms[i+2]])
            i += 3
        elif atom == ion:
            ion_atom = atoms[i]
            i += 1
        else:
            i += 1

    # water dimers with no double_counting
    water_water_dimers = [(water_molecules[i], water_molecules[j]) 
                          for i in range(len(water_molecules)) 
                          for j in range(i + 1, len(water_molecules))]

    # water-ion dimers
    water_ion_dimers = [(water, ion_atom) for water in water_molecules] if ion_atom else []

    return water_water_dimers, water_ion_dimers
def save_cluster_to_file(cluster, filename):
    with open(filename, 'w') as f:
        f.write(f"{len(cluster)}\n\n")  
        for line in cluster:
            f.write(line)

def save_dimers_to_file(water_water_filename, water_ion_filename, water_water_dimers, water_ion_dimers, cluster_index, ion):
    # Save water-water dimers
    with open(water_water_filename, 'a') as f:
        for i, dimer in enumerate(water_water_dimers):
            water1, water2 = dimer
            f.write(f"6\nWater-Water Dimer {i+1} from {ion} Cluster {cluster_index}\n")
            for atom in water1 + water2:
                f.write(f"{atom[0]} {atom[1][0]:.8f} {atom[1][1]:.8f} {atom[1][2]:.8f}\n")

    with open(water_ion_filename, 'a') as f:
        for i, dimer in enumerate(water_ion_dimers):
            water, ion_atom = dimer
            f.write(f"4\nWater-{ion} Dimer {i+1} from {ion} Cluster {cluster_index}\n")
            for atom in water + [ion_atom]:
                f.write(f"{atom[0]} {atom[1][0]:.8f} {atom[1][1]:.8f} {atom[1][2]:.8f}\n")

def main():
    input_filename = "ion_water_mbe_eda_wb97xv_tzvppd_opt.xyz"  

    ion_types = ['Ca', 'K', 'Mg', 'Na', 'F', 'Cl', 'Br', 'I', 'Rb', 'Cs']
    
    for ion in ion_types:
        ion_cluster_directory = f"{ion.lower()}_clusters"
        if not os.path.exists(ion_cluster_directory):
            os.makedirs(ion_cluster_directory)  

        water_water_output_filename = f"{ion.lower()}_water_water_dimers.xyz"
        water_ion_output_filename = f"{ion.lower()}_water_{ion.lower()}_dimers.xyz"

        clusters = parse_xyz_file(input_filename)

        ion_clusters = filter_ion_clusters(clusters, ion)

        for i, cluster in enumerate(ion_clusters, 1):  
            cluster_filename = os.path.join(ion_cluster_directory, f"{ion.lower()}_cluster_{i}.xyz")
            save_cluster_to_file(cluster, cluster_filename)

            atoms = parse_cluster(cluster)
            water_water_dimers, water_ion_dimers = generate_dimers(atoms, ion)

            save_dimers_to_file(water_water_output_filename, water_ion_output_filename, water_water_dimers, water_ion_dimers, i, ion)

        print(f"Generated dimers for {len(ion_clusters)} {ion} clusters and saved to {water_water_output_filename} and {water_ion_output_filename}")
        print(f"{ion} clusters saved to directory: {ion_cluster_directory}")

# Run the main function
if __name__ == "__main__":
    main()
