import torch
import numpy as np
from utils import load_xyz, hyb_n
import os

current_dir = os.getcwd()
filepath_cluster = os.path.join(current_dir, 'f_water_f_dimers.xyz')
xyz = load_xyz(filepath_cluster)

#Calculte the input hybrid matrices
hyb_cluster = hyb_n(xyz)


device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
x_cluster = torch.tensor(hyb_cluster)
cluster_size = len(xyz)
x_cluster = x_cluster.view(cluster_size, 16)
x_cluster = x_cluster.to(torch.float32).to(device)

model = torch.load(current_dir + "/" + "best_model.pt", map_location=torch.device('cpu'))
model = model.to(device)
model.eval()
with torch.no_grad():
    output = model(x_cluster)

output_numpy = output.cpu().numpy()
np.savetxt(current_dir + "/" + 'valid_output.txt', output_numpy, fmt='%.6f', delimiter=' ')

# labelling #
labels = ['cls_elec', 'ct', 'mod_pauli', 'pol', 'disp']

def label_data_with_titles(valid_output_file, xyz_file, output_file):
    energies = np.loadtxt(valid_output_file)

    titles = []
    with open(xyz_file, 'r') as xyz_f:
        lines = xyz_f.readlines()
        for i, line in enumerate(lines):
            if "Cluster" in line:
                titles.append(line.strip())  

    if len(energies) != len(titles):
        raise ValueError("Mismatch between number of energies and number of XYZ titles")

    with open(output_file, 'w') as f_out:
        f_out.write(",".join(labels) + ",title\n")  
        for i, energy in enumerate(energies):
            labeled_line = ", ".join([f"{value:.6f}" for value in energy])  
            f_out.write(f"{labeled_line},{titles[i]}\n")  

    #print(f"Labeled data saved to {output_file}")



def aggregate_cluster_contributions(labeled_file, cluster_output_file):
    cluster_sums = {}

    with open(labeled_file, 'r') as f_in:
        lines = f_in.readlines()[1:]  
        for line in lines:
            values, title = line.rsplit(',', 1)
            values = list(map(float, values.split(',')))

            cluster_info = title.strip().split("Cluster")[-1]
            cluster_number = int(cluster_info.strip())

            # Sum contributions for each cluster
            if cluster_number not in cluster_sums:
                cluster_sums[cluster_number] = np.zeros(len(labels))
            cluster_sums[cluster_number] += values  


    with open(cluster_output_file, 'w') as f_out:
        f_out.write("Cluster," + ",".join(labels) + "\n")  
        for cluster, sums in sorted(cluster_sums.items()):
            summed_line = ", ".join([f"{value:.6f}" for value in sums])
            f_out.write(f"{cluster},{summed_line}\n")



def main():
    current_dir = os.getcwd()

    valid_output_file = os.path.join(current_dir, 'valid_output.txt')
    xyz_file = os.path.join(current_dir, 'f_water_f_dimers.xyz')
    labeled_output_file = os.path.join(current_dir, 'labeled_output.txt')
    cluster_output_file = os.path.join(current_dir, 'cluster_contributions_ion.txt')

    label_data_with_titles(valid_output_file, xyz_file, labeled_output_file)

    aggregate_cluster_contributions(labeled_output_file, cluster_output_file)


if __name__ == "__main__":
    main()


