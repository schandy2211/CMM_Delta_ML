Folder: DIMERS
	-Wat_F_Dimers: CMM_deltaML model for water-F dimer data 
		-main_eda.py :To train and test the ML model. best_model.pt is saved in the "eda" folder
		-errors.py : errors in train, test and valid set is stored in "errors_nd_plots" folder
	-Wat_Wat_Dimers: CMM_deltaML model for water-water dimer data
                -main_eda.py :To train and test the ML model. best_model.pt is saved in the "eda" folder
                -errors.py : errors in train, test and valid set is stored in "errors_nd_plots" folder


Folder: CLUSTERS
	-dimers_from_clusters: This folder has cluster.py, which generates the water-water dimers and water-ion dimers for each ion-water clusters in "ion_water_mbe_eda_wb97xv_tzvppd_opt.xyz". 
Example: all F clusters can be find in the folder "f_clusters". "f_water_f_dimers.xyz" has all water_f dimers generated from each clusters. Details of dimer and cluster in the title card of .xyz file. Similarly, the water-water dimer pairs from the same cluster can be found in "f_water_water_dimers.xyz" file


	-f_wat_clust: ener_pred.py is used to predict the delta contribution using the best_model.pt from the Wat_F_Dimers folder. Individual eda delta contribution from each dimer from the cluster can be found in labeled_output.txt. And the summed contribution at "cluster_contributions_ion.txt"

	-wat_wat_clust: Similar files as f_wat_cluster folder. The summed contribution of each cluster from the water-water dimer is at  "cluster_contributions_water.txt" 


Folder: dft_vs_cmm
	-the mae_cluster.ipynb calculate the MAE and R2 score of 1) DFT VS CMM of all EDA terms(including MB) 2) DFT VS CMM+delta 3) DFT VS CMM for 2b terms 4) DFT VS CMM+delta for 2b terms
	- .ipynb need "cluster_contributions_ion.txt" and "cluster_contributions_water.txt" files, and EDA data from "ion_water_mbe_eda_wb97xv_qzvppd.csv" and "ion_water_mbe_eda_cmm.csv"





